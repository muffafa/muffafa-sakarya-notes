﻿namespace H3WebYaz.Models
{
    public class Ogrenci
    {
        public string OgrAd { get; set; }
        public string OgrSoyad { get; set; }
        public string OgrNo { get; set; }
    }
}
